package com.tapwithus.sdk.bluetooth.callbacks;

public interface OnNotFoundListener<T> {
    void onNotFound(String message);
}
