package com.tapwithus.sdk.bluetooth.callbacks;

public interface OnErrorListener {
    void onError(String msg);
}
